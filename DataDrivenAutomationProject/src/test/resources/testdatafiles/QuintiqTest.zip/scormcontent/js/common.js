var adjustFooterTimer = null;

function autoAdjustFooter(){
    $(window).load(function(){
        adjustFooter();
    });
    
    $(window).resize(function(){
        clearTimeout(adjustFooterTimer);
        
        adjustFooterTimer = setTimeout(function(){
            adjustFooter();
        }, 20);
    });
    
}

function adjustFooter(){
    var contentH = $('.content:first').offset().top + $('.content:first').outerHeight(true);
    var tocH = $('.toc:first').outerHeight(true) + $('.toc:first').offset().top;
    var winH = $(window).height();
    var footerH = $('#footer').outerHeight();
    
    if(tocH > contentH){
        contentH = tocH;
    }
    
    if(winH < contentH + footerH){
        $('#footer').removeClass('sticky');
    }else{
        $('#footer').addClass('sticky');
    }
}

//Bind custom scroller for container
function bindScroller(scrollBar, scrollContent, sensitivity){
	$(scrollBar).slider({
		animate: false,
		change: function(e, ui){
			updateScrollChanges(ui.value, scrollBar, scrollContent);
		},
		slide: function(e, ui){
			updateScrollChanges(ui.value, scrollBar, scrollContent);
		},
		orientation: 'vertical',
		value: 100 
	});
    
    if(sensitivity != '' && sensitivity != null){
        sensitivity = parseInt(sensitivity);
    }else{
        sensitivity = 3;
    }
    
	$(scrollContent).mousewheel(function(e,delta){
		e.preventDefault();
		$(scrollBar).slider('value', $(scrollBar).slider('value') + (delta*sensitivity));
	});
	$(scrollContent).scrollTop(0);
	updateScrollChanges(null, scrollBar, scrollContent);
	updateScrollerActivation(scrollBar, scrollContent);
}

function resetScrollerPos(scrollBar, scrollContent){
    $(scrollContent).scrollTop(0);
    $(scrollBar).slider('value', 100);
}

function updateScrollerActivation(scrollBar, scrollContent){
	var childrenTotalHeight = 0;
	var scrollContentHeight = parseInt($(scrollContent).height());
	$(scrollContent).children().each(function(){
		childrenTotalHeight += parseInt($(this).outerHeight());	
	});
	
	if(childrenTotalHeight <= scrollContentHeight){
		$(scrollBar).find('.ui-slider-handle').hide();
	}else{
		$(scrollBar).find('.ui-slider-handle').show();
	}
}

function forceScrollerActive(scrollBar){
	$(scrollBar).find('.ui-slider-handle').show();
}

function updateScrollChanges(scrollValue, scrollBar, scrollContent){
	if(scrollValue != null){
		var maxScroll = $(scrollContent).prop('scrollHeight') - $(scrollContent).height();
		$(scrollContent).scrollTop((100 - scrollValue) * (maxScroll / 100));
	}
}