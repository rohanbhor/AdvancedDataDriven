function Quiz() {
	//element
	this.node = {};
	
	//question types
	this.QUESTION_TYPE_MULTICHOICE = 'multichoice';
	this.QUESTION_TYPE_TRUEFALSE = 'truefalse';
	
	//options
	this.randomize = false;
	this.passingScore = 80;
	
	this.initializeQuestions = function (url,datatype) {
		var obj = this;
		
		log('loading assessment datafile from '+url);
		switch(datatype) {
			case 'json':
				$.ajax ({
					type: "GET",
					url: url,
					dataType: 'json',
					success: function(data) {
						obj.loadQuestions(data);
					},
					error: function(xhr, ajaxOptions, thrownError) {
						log('error loading data',this,arguments);
					}
				});
				break;
		}
	};
	
	this.loadQuestions = function (data) {
		var obj = this;
		var str = "<form id='frmTest' action='#'>";
		
		//load questions
		this.bank = data;

		if (this.randomize == true) {
			
		}
		
		for (var i = 0; i < this.bank.questions.length; i++) {
			
			//
			
			var num = (i + 1) + ". ";
					
			str += "<div style=\"margin-bottom:20px;\">";
			str = str + num + this.displayQuestions(this.bank.questions[i]);
			str += "</div>";
		}
		
		str += "<input type='button' id='btnSubmit' value='Submit Answers'></form>";

		var elem = $(this.node);
		elem.append(str);
		elem.on("click", "#btnSubmit", function() {
			obj.gradeQuestions();
		});
	};
	
	this.displayQuestions = function (question) {
		var str = "";
		
		str += question.questiontext;
		str += "<p></p>";
		
		if (question.type == this.QUESTION_TYPE_MULTICHOICE) {
			for (var i = 0; i < question.answers.length; i++) {
				if (question.single == true) {
					str = str + '<input id="resp_' + question.id + '_' + question.answers[i].id + '" name="resp_' + question.id + '" type="radio" value="">';
				}
				else {
					str = str + '<input id="resp_' + question.id + '_' + question.answers[i].id + '" name="resp_' + question.id + '" type="checkbox" value="">';
				}
				str = str + '<label for=""><span class="anun">' + String.fromCharCode(97+i) + '<span class="anumsep">.</span></span>' + question.answers[i].answertext + '</label>';
			}
		}
		else if (question.type == this.QUESTION_TYPE_TRUEFALSE) {
			for (var i = 0; i < question.answers.length; i++) {
				str = str + '<input id="resp_' + question.id + '_' + question.answers[i].answertext + '" name="resp_' + question.id + '" type="radio" value="">';
				str = str + '<label for="">' + question.answers[i].answertext + '</label>';
			}
		}

		return str;
	};
	
	this.gradeQuestions = function () {
		var question = null;
		var score = 0;
		var finalScore = 0;

		for (var questionIndex = 0; questionIndex < this.bank.questions.length; questionIndex++) {
			
			//
			question = this.bank.questions[questionIndex];

			switch (question.type){
				case this.QUESTION_TYPE_MULTICHOICE:
					for (var answerIndex = 0; answerIndex < question.answers.length; answerIndex++) {
						//
						log("#resp_" + question.id + '_' + question.answers[answerIndex].id);
                        if ($("#resp_" + question.id + '_' + question.answers[answerIndex].id).is(':checked') == true) {
                            score += question.answers[answerIndex].fraction;
                        }
					}
					break;
				
				case this.QUESTION_TYPE_TRUEFALSE:
					if ($("#resp_" + question.id + '_True').is(':checked') == true) {
						//loop through answer, find the one with text = true
						for (var answerIndex = 0; answerIndex < question.answers.length; answerIndex++) {
							if (question.answers[answerIndex].answertext == "True") {
								score += question.answers[answerIndex].fraction;
							}
						}
					}
					if ($("#resp_" + question.id + '_False').is(':checked') == true) {
						//loop through answer, find the one with text = false
						for (var answerIndex = 0; answerIndex < question.answers.length; answerIndex++) {
							if (question.answers[answerIndex].answertext == "False") {
								score += question.answers[answerIndex].fraction;
							}
						}
					}
					break;
			}
		}
		
		//calculate
		finalScore = score / this.bank.questions.length * 100;
		if (finalScore < 0) finalScore = 0;
		if (finalScore >= this.passingScore) {
			log(finalScore + " passed!");
		}
		else {
			log(finalScore + " failed!");
		}
	};
};


// usage: log('inside coolFunc', this, arguments);
// paulirish.com/2009/log-a-lightweight-wrapper-for-consolelog/
window.log = function(){
  log.history = log.history || [];   // store logs to an array for reference
  log.history.push(arguments);
  arguments.callee = arguments.callee.caller;  
  if(this.console) console.log( Array.prototype.slice.call(arguments) );
};
// make it safe to use console.log always
(function(b){function c(){}for(var d="assert,count,debug,dir,dirxml,error,exception,group,groupCollapsed,groupEnd,info,log,markTimeline,profile,profileEnd,time,timeEnd,trace,warn".split(","),a;a=d.pop();)b[a]=b[a]||c})(window.console=window.console||{});


// place any jQuery/helper plugins in here, instead of separate, slower script files.